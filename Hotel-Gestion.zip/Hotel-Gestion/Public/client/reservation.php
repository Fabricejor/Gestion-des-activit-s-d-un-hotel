<?php
global $mysqli;
session_start();
if (!isset($_SESSION['logged_in'])){
    header('Location: connexion.php');
    exit();
}

$idClient = $_SESSION['idClient'];

include 'config.php';

// La date de reservation
$dateDuJour = date('Y-m-d');

// Ajouter une reservation
if (isset($_POST['reserve'])) {
    $entree = $_POST['entree'];
    $sortie = $_POST['sortie'];
    $adulte = $_POST['nb_adulte'];
    $enfant = $_POST['nb_enfant'];
    $c_chambre = $_POST['c_chambre'];
    $nb_chambre = $_POST['nb_chambre'];

    // if password don't match
    if ($entree >= $sortie) {
        $_SESSION['error'] = "La date d'entrée doit etre antérieur à la date de sortie";
        header('Location: reservation.php');
        exit();
    }

    // id du système (idperso)
    $idperso = 19;

    // recupérer l'id de la categorie
    $stmt1 = $mysqli->prepare("SELECT idcategorie FROM categorie WHERE nom = ?");
    $stmt1->bind_param('s', $c_chambre);
    $stmt1->execute();
    $stmt1->bind_result($idCategori);
    $stmt1->fetch();
    $stmt1->close();

    // id de la chambre
    $stmt = $mysqli->prepare("SELECT numero FROM chambre WHERE idcategorie = ? AND etat = 'disponible'");
    $stmt->bind_param('s', $idCategori);
    $stmt->execute();
    $stmt->bind_result($numero);
    $stmt->store_result();
    $stmt->fetch();

        // Changé le status de la reservation
        $status_reservation = 'confirmé';

        // Si la chambre est disponibble
    if ($stmt->num_rows > 0) {
        // Ajouter une nouvelle reservation
        $sql = $mysqli->prepare("INSERT INTO reservation (dateReservation, entré, sortie, Nbadulte, Nbenfant, Nbchambre, statusReservation, numero, idperso, idclient) 
                                VALUES (?,?,?,?,?,?,?,?,?,?)");

        $sql->bind_param('ssssssssss', $dateDuJour, $entree, $sortie, $adulte, $enfant, $nb_chambre, $status_reservation, $numero, $idperso, $idClient);

        // Si la reservation a bien ete creer
        if ($sql->execute()){
            // Modifier l'etat de la chambre disponible -> occupé
            $mysqli->query("UPDATE chambre SET etat='occupe' WHERE numero='$numero'" );
            $_SESSION['numero'] = $numero;
            $_SESSION['creer'] = "Reservation ajouté avec success";
            header("Location: reservation.php?idcategorie=" . urlencode($idCategori) . "numero=".urlencode($numero));
            exit();
            // Si le personnel n'a pas été creer
        }else{
            $_SESSION['er'] = "Echec de la reservation";
            header('Location: reservation.php');
            exit();
        }
    } else {
        $_SESSION['error'] = "Desolée aucune chambre de cette categorie n'est disponible";
        header('Location: reservation.php');
        exit();
    }

}

// Afficher les categories de chambres
$stmt = $mysqli->prepare("SELECT idcategorie, nom, description, nuité, image FROM categorie");
$stmt->execute();
$stmt->bind_result($idcategorie, $nom, $description, $nuite, $imageData);



?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.0-beta1/js/bootstrap.min.js">

<title>reservations</title>

<body style="background: #eeeeee">

<!-- Modal reservation Starts-->

<div class="modal fade" id="reservation" tabindex="-1"
     aria-labelledby="myModal" aria-hiden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title" id="myModalLabel">Reservation en ligne</h5>
                <button type="button" class="btn-close"
                        data-bs-dismiss="modal" aria-label="close"></button>
            </div>
            <div class="modal-body">
                <form action="reservation.php" method="post" onsubmit="return validateForm(event)" id="reservationForm">
                    <div class="mb-3">
                        <label for="date_entree" class="form-label"
                               aria-describedby="dsortieHelp">Date d'entrée</label>
                        <input name="entree" id="date_entree" type="date" class="form-control" min="<?php echo $dateDuJour ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="date_sortie" class="form-label"
                               aria-describedby="dentreeHelp">Date de sortie</label>
                        <input name="sortie" id="date_sortie" type="date" class="form-control" min="<?php echo $dateDuJour ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="nb_adultes" class="form-label"
                               aria-describedby="nbadulteHelp">Nombre d'adultes</label>
                        <input name="nb_adulte" id="nb_adultes" type="number" class="form-control" required min="1" max="3">
                    </div>
                    <div class="mb-3">
                        <label for="nb_enfants" class="form-label"
                               aria-describedby="nbenfantsHelp">Nombre d'enfants</label>
                        <input name="nb_enfant" id="nb_enfants" type="number" class="form-control" required min="0" max="5">
                    </div>
                    <div class="mb-3">
                        <label for="ch_categorie">Categorie de chambre</label>
                        <select name="c_chambre" class="form-select"
                                aria-label="typeChambre" id="ch_categorie">
                            <option value="classiques">classiques</option>
                            <option value="affaires">affaires</option>
                            <option value="luxe">luxe</option>
                            <option value="couples">couples</option>
                            <option value="economiques">economiques</option>
                            <option value="famille">famille</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="nb_chambres" class="form-label"
                               aria-describedby="nbchambresHelp">Nombre de chambres</label>
                        <input name="nb_chambre" id="nb_chambres" type="number" class="form-control" required value="1" readonly>
                    </div>
                    <input class="btn btn-info" type="submit" id="reserver" name="reserve" value="Reserver">
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal reservation Ends-->

<!-- navbar Start -->

<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-transparent py-0">
    <div class="container-fluid">
        <button class="navbar-toggler "
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarToggler"
                aria-expanded="false"
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <a href="reservation.php" class="navbar-brand ">
            <img src="logo.png" class="rounded-circle" alt="" width="60px" height="60px">
        </a>

        <div class="collapse navbar-collapse " id="navbarToggler">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 " style="margin-left: 15%">
                <li class="nav-item fw-bolder">
                    <a href="client.php" class="nav-link ">Accueil</a>
                </li>
                <!--<li class="nav-item fw-bolder">
                    <a href="reservation.php" class="nav-link active">Reservation</a>
                </li>-->
                <li class="nav-item">
                    <a href="reservation.php" class="nav-link active fw-bolder">Reserver chambres</a>
                </li>
                <li class="nav-item">
                    <a href="mes_reservations.php" class="nav-link fw-bolder">Mes reservations</a>
                </li>
                <li class="nav-item">
                    <a href="contact.php" class="nav-link fw-bolder">Contactez-nous</a>
                </li>

            </ul>
            <form class="d-flex">
                <input type="search" class="form-control me-2" placeholder="Search">
                <button class="btn btn-outline-info type="submit">Search</button>
            </form>
            <ul class="navbar-nav mb-2 mb-lg-0" style="margin-right: 7%">
                <li class="nav-item dropdown" >
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512" class="ms-5"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z"/></svg>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><p class="dropdown-item" href="#"><?php if (isset($_SESSION['prenom']) && isset($_SESSION['nom'])){echo $_SESSION['prenom'] . ' '. $_SESSION['nom'];} ?></p></li>
                        <li><a class="dropdown-item" href="#"><?php if (isset($_SESSION['couriel'])){echo $_SESSION['couriel'];} ?></a></li>
                        <li><a class="dropdown-item" href="connexion.php?logout=1">Deconnexion</a></li>
                    </ul>
                </li>
            </ul>

        </div>
    </div>
</nav>

<!-- navbar End -->

<!-- carousel start -->
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel" >
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://github.com/Fabricejor/Gestion-des-activit-s-d-un-hotel/blob/main/images/Chambre%20de%20luxe.jpg?raw=true" class="d-block" style="width: 100%; height: 75%" alt="...">
            <div class="carousel-caption d-none d-md-block">
                <h5>Tarifs chambres et offres</h5>
                <p>Some representative placeholder content for the first slide.</p>
            </div>
        </div>
        <div class="carousel-item">
            <div class="carousel-caption d-none d-md-block">
                <h5>Tarifs chambres et offres</h5>
                <p>Some representative placeholder content for the first slide.</p>
            </div>
            <img src="https://github.com/Fabricejor/Gestion-des-activit-s-d-un-hotel/blob/main/images/chambre%20famille.jpg?raw=true" class="d-block " style="width: 100%; height: 75%" alt="...">

        </div>
        <div class="carousel-item">
            <img src="https://github.com/Fabricejor/Gestion-des-activit-s-d-un-hotel/blob/main/images/chambre%20classique.jpg?raw=true" class="d-block" style="width: 100%; height: 75%" alt="...">
            <div class="carousel-caption d-none d-md-block">
                <h5>Tarifs chambres et offres</h5>
                <p>Some representative placeholder content for the first slide.</p>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<!-- carousel end -->

<?php
if (isset($_SESSION['error'])) {?>
    <div class="mt-5 alert alert-danger">
        <?php echo '<p>' . $_SESSION['error'] . '</p>';
        unset($_SESSION['error']); ?>
    </div>
<?php } ?>

<?php
if (isset($_SESSION['err'])) { ?>
    <div class="mt-5 alert alert-danger">
        <?php
        echo '<p>' . $_SESSION['err'] . '</p>';
        unset($_SESSION['err']); ?>
    </div>
<?php } ?>
<?php
if (isset($_SESSION['er'])) {?>
    <div class="mt-5 alert alert-danger">
        <?php
        echo '<p>' . $_SESSION['er'] . '</p>';
        unset($_SESSION['er']);?>
    </div>
<?php } ?>

<?php
if (isset($_SESSION['creer'])) {?>
    <div class="mt-5 alert alert-success">
        <?php echo '<p>' . $_SESSION['creer'] . '</p>';
        unset($_SESSION['creer']); ?>
    </div>
<?php } ?>

<section class="container mt-5" style="min-height: 390px;">
    <div class="row row-cols-2 row-cols-md-3 mb-3 text-center" >
        <?php while ($stmt->fetch()) {
            $imageData = base64_encode($imageData);
            ?>
            <div class="col">
                <div class="card mb-4 border-0 shadow-lg">
                    <?php echo "<img class='card-img-top' src='data:image/jpeg;base64,$imageData' alt='Image de la catégorie' width='200' height='200'>"; ?>
                    <div class="card-header bg-warning">
                        <h4 class="my-0 fw-normal">Tarifs chambres <?php echo $nom; ?></h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">Nuité :
                            <?php echo $nuite; ?><small class="text-muted">fcfa</small></h1>
                        <ul class="list-unstyled mt-3 mb-4">
                            <li><?php echo $description; ?></li>
                        </ul>
                        <button type="button" class="w100 btn btn-lg btn-info text-white fw-bold" data-bs-toggle="modal" data-bs-target="#reservation">
                            Reserver cette chambre Maintenant!
                        </button>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</section>



<!-- footer start -->
<footer class="bg-light text-center text-lg-start top-100 bottom-0 w-100">
    <nav class="navbar navbar-dark bg-dark mb-0 " >
        <div class="container-fluid text-white text-decoration-none">
            <p>&copy; 2020-2023 RSN, Inc. &middot;
                <a href="#" class="text-decoration-none text-white">Privacy</a>
                &middot;<a href="#" class="text-decoration-none text-white">Terms</a>
            </p>

            <p>
                <a href="#" class="text-decoration-none text-white">Retouner en haut de page</a>
            </p>
            <div class="footer-social">
                <span>Suivez-nous sur:</span>
                <a href="#" class="text-warning">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                        <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
                    </svg>
                </a>

                <a href="#" class="text-warning">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                        <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
                    </svg>
                </a>

                <a href="#" class="text-warning">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                        <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
                    </svg>
                </a>

                <a href="#" class="text-warning">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16">
                        <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408L6.4 5.209z"/>
                    </svg>
                </a>

                <a href="#" class="text-warning">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-tiktok" viewBox="0 0 16 16">
                        <path d="M9 0h1.98c.144.715.54 1.617 1.235 2.512C12.895 3.389 13.797 4 15 4v2c-1.753 0-3.07-.814-4-1.829V11a5 5 0 1 1-5-5v2a3 3 0 1 0 3 3V0Z"/>
                    </svg>
                </a>
            </div>
        </div>
    </nav>
</footer>
<!-- footer end -->

</body>

