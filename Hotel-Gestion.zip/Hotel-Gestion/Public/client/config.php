<?php
$conn = mysqli_connect("localhost","root", "root", "hotelbd")
or die("Connexion impossible");
?>

<?php
// Informations de connexion à la base de données
$serveur = "localhost"; // Adresse du serveur MySQL
$utilisateur = "root"; // Nom d'utilisateur MySQL
$motDePasse = "root"; // Mot de passe MySQL
$baseDeDonnees = "hotelbd"; // Nom de la base de données

// Connexion à la base de données
$mysqli = new mysqli($serveur, $utilisateur, $motDePasse, $baseDeDonnees);

// Vérifier la connexion
if ($mysqli->connect_error) {
    die("La connexion à la base de données a échoué : " . $mysqli->connect_error);
}

// Fermer la connexion
//$mysqli->close();
?>

