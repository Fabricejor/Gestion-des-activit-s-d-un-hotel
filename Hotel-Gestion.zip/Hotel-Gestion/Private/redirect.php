<?php
    session_start();

    include 'BD/LinkDB.php';

    if (isset($_SESSION['email']) && !empty($_SESSION['email']) && isset($_SESSION['role']) && !empty($_SESSION['role'])) {
    setcookie('role',$_SESSION['role'],time()+60*60*24); //on utilise le cookie pour definir le temps de sessions
    setcookie('email',$_SESSION['email'],time()+60*60*24); //on utilise le cookie pour definir le temps de sessions
        switch ($_SESSION['role']) {
            case 'admin':
                $_SESSION['idmin'] = $_SESSION['idmin'];
                header('location:Roles/Admin');
                break;

            case 'receptioniste':
                $_SESSION['idperso'] = $_SESSION['idperso'];
                header('location:Roles/Receptioniste/');

                break;

            case 'menageres':

                header('location:Roles/Menageres');

                break;

            case 'directeur':

                header('location:Roles/Directeur');

                break;

            case 'gerant':

                header('location:Roles/Gerant');

                break;
            default:
                header('location:connexion.php');

                break;
        }
    }else {
        header("location:connexion.php");
    }
?>