<?php
session_start();

    print "<h1> bienvenue ".$_SESSION['email'] ."</h1> <br>";

?>
