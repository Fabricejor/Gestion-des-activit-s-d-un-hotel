<?php
// Paramètres de connexion à la base de données
$serveur = 'localhost';
$nomUtilisateur = 'root';
$motDePasse = '';
$nomBaseDeDonnees = 'hotelbd';

try {
    // Création de l'objet PDO pour la connexion à la base de données
    $connexion = new PDO("mysql:host=$serveur;dbname=$nomBaseDeDonnees", $nomUtilisateur, $motDePasse);

    // Configuration des options PDO
    $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $connexion->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    // ... Ajoutez d'autres options si nécessaire

    // Retourne l'objet PDO pour une utilisation ultérieure
    return $connexion;
} catch (PDOException $e) {
    // En cas d'erreur de connexion, affichez le message d'erreur
    echo "Erreur de connexion : " . $e->getMessage();
    // Vous pouvez choisir de gérer l'erreur d'une autre manière si nécessaire
}
?>
